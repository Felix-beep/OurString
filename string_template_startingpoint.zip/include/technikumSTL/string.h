#pragma once

namespace technikum
{
  int add(int, int);
}

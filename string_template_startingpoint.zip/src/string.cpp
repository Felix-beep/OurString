#include "technikumSTL/string.h"

int technikum::add(int a, int b) { return a + b; }
